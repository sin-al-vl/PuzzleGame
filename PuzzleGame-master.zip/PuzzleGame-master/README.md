# PuzzleGame
A test-task for a mysterious development team
